package logica;

/**
 *
 * @author Kristien
 */
public class Punt {
    private int x;
    private int y;

    //default constructor
    public Punt() {
    }
    
    //niet-default constructor
    public Punt(int x, int y) {
        this.x = x;
        this.y = y;
    }

    //getters
    public int getX() {
        return x;
    }
    
    public int getY() {
        return y;
    }

    //setters
    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
    
    //methoden
    public String geefCoordinaten() {
        return "(" + this.x + ", " + this.y + ")";
    }

    /**
     * geeft de afstand tussen het huidig punt en het meegegeven ander punt
     * @param p het andere punt
     * @return de berekende afstand tot het andere punt
     */
    public double berekenAfstand(Punt p) {
        double afstand = Math.sqrt(Math.pow(this.x - p.x, 2) 
                                 + Math.pow(this.y - p.y, 2));

        return afstand;
    }
    
    /**
     * geeft de afstand tussen 2 punten, waarvan de resp. x- en y- coördinaten worden meegegeven
     * @param x1 x-coördinaat van eerste punt
     * @param y1 y-coördinaat van eerste punt
     * @param x2 x-coördinaat van tweede punt
     * @param y2 y-coördinaat van tweede punt
     * @return de afstand tussen beide punten
     */
    public static double berekenAfstand(int x1, int y1, int x2, int y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
}
