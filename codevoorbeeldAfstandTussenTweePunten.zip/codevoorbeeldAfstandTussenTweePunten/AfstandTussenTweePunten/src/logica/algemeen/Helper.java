package logica.algemeen;

import java.text.DecimalFormat;

/**
 *
 * @author Kristien
 */
public class Helper {
    /**
     * Zoekt het gemiddelde van een rijd van gehele getallen
     * @param getallen
     * @return het gemiddelde
     */
    public static double zoekGemiddelde(int[] getallen) {
        double som = 0;
        for (int i : getallen) {
            som += i;
        }
        return som/getallen.length;
    }

    /**
     * minimum waarde bepalen van een rij van reële getallen
     * @param getallen
     * @return het minimum
     */
    public static double zoekMinimum(double[] getallen)  {
        double kleinste = getallen[0];

        for (int i = 1; i < getallen.length; i++) {
            if (getallen[i] < kleinste) {
                kleinste = getallen[i];
            }
        }

        return kleinste;
    }

    public static int zoekMinimumInt(int[] getallen)  {
        int kleinste = getallen[0];

        for (int i = 1; i < getallen.length; i++) {
            if (getallen[i] < kleinste) {
                kleinste = getallen[i];
            }
        }

        return kleinste;
    }    
    /**
     * maximum waarde bepalen van een rij van reële getallen
     * @param getallen
     * @return het maximum
     */
    public static double zoekMaximum(double[] getallen)  {
        double grootste = getallen[0];

        for (int i = 1; i < getallen.length; i++) {
            if (getallen[i] > grootste) {
                grootste = getallen[i];
            }
        }

        return grootste;
    }
    
    public static int zoekMaximumInt(int[] getallen)  {
        int grootste = getallen[0];

        for (int i = 1; i < getallen.length; i++) {
            if (getallen[i] > grootste) {
                grootste = getallen[i];
            }
        }

        return grootste;
    }

    /**
     * afronden van een getal tot op een opgegeven aantal cijfers na de komma
     * @param getal het af te ronden getal
     * @param digitsNaKomma het gewenst aantal cijfers na de komma
     * @return de afgeronde waarde (een double)
     */
    public static double afronden(double getal, int digitsNaKomma) {
        return Math.round(getal * Math.pow(10, digitsNaKomma)) / Math.pow(10, digitsNaKomma);
    }

    /**
     *
     * @param getal het af te ronden getal
     * @param format het gewenst aantal cijfers na de komma
     * @return de afgeronde waarde (tekstuele representatie)
     */
    public static String afronden(double getal, String format) {
        DecimalFormat df = new DecimalFormat(format);
        return df.format(getal);
    }
    
    /**
     * grootste gemene deler zoeken van 2 opgegeven gehele getallen
     * @param a eerste getal (pos of neg)
     * @param b tweede getal (pos of neg)
     * @return de grootste gemene deler (pos of neg)
     */
    public static int ggd(int a, int b) {
        //http://nl.wikipedia.org/wiki/Algoritme_van_Euclides
        int rest;

        while (b != 0) {
            rest = a % b;
            a = b;
            b = rest;
        }

        return a;
    }

    /**
     * kleinste gemeen veelvoud zoeken van 2 opgegeven gehele getallen
     * @param a eerste getal
     * @param b tweede getal
     * @return het kleinste gemeen veelvoud
     */
    public static int kgv(int a, int b) {
        //onderstaande implementatie berust op wetenschap dat
        //het product van 2 getallen steeds gelijk is aan het product van hun ggd en kgv !
        return (a * b) / ggd(a, b);
    }
}
