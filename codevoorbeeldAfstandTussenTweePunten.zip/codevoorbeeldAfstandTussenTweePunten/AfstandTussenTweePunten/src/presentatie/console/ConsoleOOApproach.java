package presentatie.console;

import logica.Punt;
import java.text.DecimalFormat;

public class ConsoleOOApproach {
    public static void main(String[] args) {
        int x1 = 1;
        int y1 = 2;
        int x2 = 3;
        int y2 = 4;
        
        //OO approach
        Punt p1 = new Punt(x1, y1);
        Punt p2 = new Punt(x2, y2);
        double afstand = p1.berekenAfstand(p2);
        
        System.out.println("eerste punt: " + p1.geefCoordinaten());
        System.out.println("tweede punt: " + p2.geefCoordinaten());
        System.out.println("afstand tussen beide punten = " + afstand);
        
        //afronden aan de hand van de java.text.DecimalFormat klasse
        DecimalFormat df = new DecimalFormat("0.00");
        String res = df.format(afstand);
        System.out.println("afstand afgerond = " + res);        
    }
}
