package presentatie.console;

public class ConsoleFunctionalApproach {
    public static void main(String[] args) {   
        int x1 = 1;
        int y1 = 2;
        int x2 = 3;
        int y2 = 4;
        
        //Functional approach
        double afstand = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
        System.out.println("afstand = " + afstand);
        
        double afstandAfgerond = Math.round(afstand * 100) / 100.0;
        System.out.println("afstand afgerond = "  + afstandAfgerond);        
    }
}
