package presentatie.console;

import logica.algemeen.Helper;
import logica.Punt;

public class ConsoleStaticApproach {
    public static void main(String[] args) { 
        int x1 = 1;
        int y1 = 2;
        int x2 = 3;
        int y2 = 4;

        //static approach
        double afstand = Punt.berekenAfstand(x1, y1, x2, y2);
        System.out.println("afstand = " + afstand);
        System.out.println("afstand afgerond = " + Helper.afronden(afstand, 2));
        System.out.println("afstand afgerond bis = " + Helper.afronden(afstand, "0.000"));        
    }
}
